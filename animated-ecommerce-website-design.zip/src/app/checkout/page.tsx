"use client";

import { Button } from "@/components/ui/Button";
import { useCart } from "@/components/providers/CartProvider";
import { createOrder } from "@/lib/data";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";
import { CreditCard, Lock, Truck } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function CheckoutPage() {
  const { items, totalPrice, clearCart } = useCart();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    email: "",
    name: "",
    address: "",
    city: "",
    country: "",
    postalCode: "",
  });

  if (items.length === 0) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6 pt-24 text-center">
        <h1 className="text-2xl font-bold">Your cart is empty</h1>
        <p className="mt-2 text-slate-400">Add items before checkout.</p>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const order = await createOrder({
        ...form,
        total: totalPrice,
        items: items.map((i) => ({
          productId: i.productId,
          quantity: i.quantity,
          price: i.price,
        })),
      });
      clearCart();
      router.push(`/checkout/success?order=${order.id}`);
    } catch (err) {
      setLoading(false);
      alert("Something went wrong. Please try again.");
    }
  };

  const field = (
    label: string,
    name: keyof typeof form,
    type = "text",
    required = true
  ) => (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-slate-300">
        {label}
      </span>
      <input
        type={type}
        name={name}
        required={required}
        value={form[name]}
        onChange={(e) => setForm((f) => ({ ...f, [name]: e.target.value }))}
        className="h-12 w-full rounded-xl border border-border bg-surface-elevated px-4 text-slate-100 placeholder:text-slate-600 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        placeholder={label}
      />
    </label>
  );

  return (
    <div className="min-h-screen pt-28 pb-16">
      <div className="mx-auto max-w-7xl px-6">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl font-bold tracking-tight md:text-4xl"
        >
          Checkout
        </motion.h1>

        <div className="mt-10 grid gap-10 lg:grid-cols-3">
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            onSubmit={handleSubmit}
            className="space-y-5 lg:col-span-2"
          >
            <section className="rounded-3xl bg-surface-elevated p-6 md:p-8">
              <h2 className="mb-6 flex items-center gap-2 text-lg font-semibold">
                <Truck className="h-5 w-5 text-primary" /> Shipping Details
              </h2>
              <div className="grid gap-5 md:grid-cols-2">
                {field("Full Name", "name")}
                {field("Email", "email", "email")}
                {field("Address", "address")}
                {field("City", "city")}
                {field("Country", "country")}
                {field("Postal Code", "postalCode")}
              </div>
            </section>

            <section className="rounded-3xl bg-surface-elevated p-6 md:p-8">
              <h2 className="mb-6 flex items-center gap-2 text-lg font-semibold">
                <CreditCard className="h-5 w-5 text-primary" /> Payment
              </h2>
              <div className="rounded-2xl border border-dashed border-slate-600 bg-background p-8 text-center text-slate-400">
                <Lock className="mx-auto mb-3 h-8 w-8 text-slate-500" />
                <p>Secure payment processing is simulated for this demo.</p>
                <p className="mt-1 text-sm">No real card details are collected.</p>
              </div>
            </section>

            <Button
              type="submit"
              size="lg"
              className="w-full"
              isLoading={loading}
            >
              Complete Order
            </Button>
          </motion.form>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="h-fit rounded-3xl bg-surface-elevated p-6 lg:sticky lg:top-28"
          >
            <h2 className="text-lg font-semibold">Order Summary</h2>
            <div className="mt-6 max-h-64 space-y-3 overflow-y-auto pr-2">
              {items.map((item) => (
                <div key={item.productId} className="flex justify-between text-sm">
                  <span className="text-slate-300">
                    {item.name} <span className="text-slate-500">x{item.quantity}</span>
                  </span>
                  <span className="font-medium text-white">
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-6 space-y-3 border-t border-border pt-6 text-sm">
              <div className="flex justify-between text-slate-400">
                <span>Subtotal</span>
                <span>{formatPrice(totalPrice)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between text-lg font-bold text-white">
                <span>Total</span>
                <span>{formatPrice(totalPrice)}</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
