"use server";

import { db } from "@/db";
import { categories, orderItems, orders, products } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

const categorySeed = [
  {
    name: "Women",
    slug: "women",
    description: "Elegant dresses, tops, and curated looks for her.",
    imageUrl:
      "https://images.pexels.com/photos/38652629/pexels-photo-38652629.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  {
    name: "Men",
    slug: "men",
    description: "Refined tailoring, footwear, and everyday essentials for him.",
    imageUrl:
      "https://images.pexels.com/photos/26741255/pexels-photo-26741255.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    name: "Accessories",
    slug: "accessories",
    description: "Jewelry, bags, and finishing touches that elevate any outfit.",
    imageUrl:
      "https://images.pexels.com/photos/20943476/pexels-photo-20943476.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  {
    name: "Electronics",
    slug: "electronics",
    description: "Premium gadgets and tech designed for modern life.",
    imageUrl:
      "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
  {
    name: "Home & Living",
    slug: "home-living",
    description: "Timeless furniture and décor for inspired spaces.",
    imageUrl:
      "https://images.pexels.com/photos/7546314/pexels-photo-7546314.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    name: "Sports",
    slug: "sports",
    description: "Performance gear for active lifestyles.",
    imageUrl:
      "https://images.pexels.com/photos/11767210/pexels-photo-11767210.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  },
];

const productSeed: {
  name: string;
  slug: string;
  description: string;
  price: string;
  compareAtPrice?: string;
  images: string[];
  categorySlug: string;
  inventory: number;
  rating: string;
  reviewCount: number;
  featured: number;
}[] = [
  // Women
  {
    name: "Silk Evening Dress",
    slug: "silk-evening-dress",
    description:
      "A flowing silk evening dress with a draped silhouette, perfect for formal occasions and timeless elegance.",
    price: "189.00",
    compareAtPrice: "249.00",
    images: [
      "https://images.pexels.com/photos/9039597/pexels-photo-9039597.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "women",
    inventory: 24,
    rating: "4.8",
    reviewCount: 42,
    featured: 1,
  },
  {
    name: "Maroon Skirt Set",
    slug: "maroon-skirt-set",
    description:
      "Chic two-piece set featuring a crisp white top and flowing maroon skirt for effortless sophistication.",
    price: "129.00",
    images: [
      "https://images.pexels.com/photos/38652629/pexels-photo-38652629.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "women",
    inventory: 30,
    rating: "4.5",
    reviewCount: 18,
    featured: 0,
  },
  {
    name: "Scarlet Statement Blazer",
    slug: "scarlet-statement-blazer",
    description:
      "A bold red blazer cut to command attention in the boardroom or at after-work events.",
    price: "149.00",
    images: [
      "https://images.pexels.com/photos/38652618/pexels-photo-38652618.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "women",
    inventory: 18,
    rating: "4.7",
    reviewCount: 29,
    featured: 1,
  },
  {
    name: "Denim Chore Shirt",
    slug: "denim-chore-shirt",
    description:
      "A modern take on workwear, this denim chore shirt is as durable as it is stylish.",
    price: "79.00",
    images: [
      "https://images.pexels.com/photos/38652616/pexels-photo-38652616.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "women",
    inventory: 45,
    rating: "4.3",
    reviewCount: 12,
    featured: 0,
  },
  {
    name: "Embroidered Evening Clutch",
    slug: "embroidered-evening-clutch",
    description:
      "Hand-finished embroidered clutch with golden details, designed to complete your evening look.",
    price: "119.00",
    images: [
      "https://images.pexels.com/photos/8125856/pexels-photo-8125856.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "women",
    inventory: 20,
    rating: "4.6",
    reviewCount: 22,
    featured: 0,
  },
  // Men
  {
    name: "Tailored Grey Suit",
    slug: "tailored-grey-suit",
    description:
      "Impeccably tailored grey suit crafted from premium fabric for a sharp, confident silhouette.",
    price: "349.00",
    compareAtPrice: "499.00",
    images: [
      "https://images.pexels.com/photos/31034509/pexels-photo-31034509.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "men",
    inventory: 12,
    rating: "4.9",
    reviewCount: 56,
    featured: 1,
  },
  {
    name: "Black Leather Loafers",
    slug: "black-leather-loafers",
    description:
      "Classic black leather loafers with a sleek profile, designed for all-day comfort and polish.",
    price: "159.00",
    images: [
      "https://images.pexels.com/photos/10259873/pexels-photo-10259873.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "men",
    inventory: 28,
    rating: "4.6",
    reviewCount: 31,
    featured: 0,
  },
  // Accessories
  {
    name: "Diamond Hoop Earrings",
    slug: "diamond-hoop-earrings",
    description:
      "Sparkling diamond hoop earrings set in a minimalist design for everyday luxury.",
    price: "249.00",
    images: [
      "https://images.pexels.com/photos/20943476/pexels-photo-20943476.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "accessories",
    inventory: 15,
    rating: "4.8",
    reviewCount: 37,
    featured: 1,
  },
  {
    name: "Exquisite Diamond Bracelet",
    slug: "exquisite-diamond-bracelet",
    description:
      "A delicate diamond bracelet that catches the light with every movement.",
    price: "399.00",
    compareAtPrice: "549.00",
    images: [
      "https://images.pexels.com/photos/8306528/pexels-photo-8306528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "accessories",
    inventory: 8,
    rating: "4.9",
    reviewCount: 19,
    featured: 1,
  },
  // Electronics
  {
    name: "Aura Wireless Headphones",
    slug: "aura-wireless-headphones",
    description:
      "Immersive sound, active noise cancellation, and 30-hour battery life in a minimalist design.",
    price: "199.00",
    compareAtPrice: "249.00",
    images: [
      "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "electronics",
    inventory: 50,
    rating: "4.7",
    reviewCount: 128,
    featured: 1,
  },
  {
    name: "Neon Instant Camera",
    slug: "neon-instant-camera",
    description:
      "Capture memories with retro charm and modern neon aesthetics. Includes film starter pack.",
    price: "129.00",
    images: [
      "https://images.pexels.com/photos/16045136/pexels-photo-16045136.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "electronics",
    inventory: 22,
    rating: "4.4",
    reviewCount: 45,
    featured: 0,
  },
  {
    name: "Vertex Handheld Console",
    slug: "vertex-handheld-console",
    description:
      "A powerful handheld gaming device with a vibrant OLED display and all-day battery.",
    price: "299.00",
    images: [
      "https://images.pexels.com/photos/14005916/pexels-photo-14005916.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "electronics",
    inventory: 16,
    rating: "4.8",
    reviewCount: 92,
    featured: 1,
  },
  {
    name: "Heritage Speaker Set",
    slug: "heritage-speaker-set",
    description:
      "Room-filling sound from a sculptural speaker set crafted for audiophiles and design lovers.",
    price: "499.00",
    images: [
      "https://images.pexels.com/photos/29581125/pexels-photo-29581125.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "electronics",
    inventory: 10,
    rating: "4.9",
    reviewCount: 34,
    featured: 1,
  },
  {
    name: "Minimal USB Drive",
    slug: "minimal-usb-drive",
    description:
      "Sleek braided-loop USB drive with fast transfer speeds and a refined matte finish.",
    price: "29.00",
    images: [
      "https://images.pexels.com/photos/18641665/pexels-photo-18641665.png?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "electronics",
    inventory: 100,
    rating: "4.2",
    reviewCount: 15,
    featured: 0,
  },
  // Home & Living
  {
    name: "Minimalist Beige Sofa",
    slug: "minimalist-beige-sofa",
    description:
      "A clean-lined beige sofa upholstered in soft fabric for contemporary living rooms.",
    price: "899.00",
    compareAtPrice: "1199.00",
    images: [
      "https://images.pexels.com/photos/6707628/pexels-photo-6707628.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    categorySlug: "home-living",
    inventory: 6,
    rating: "4.7",
    reviewCount: 24,
    featured: 1,
  },
  {
    name: "Vintage Living Room Set",
    slug: "vintage-living-room-set",
    description:
      "Curated vintage set with a classic sofa, mirror accents, and warm parquet-inspired tones.",
    price: "1299.00",
    images: [
      "https://images.pexels.com/photos/18701384/pexels-photo-18701384.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    categorySlug: "home-living",
    inventory: 4,
    rating: "4.8",
    reviewCount: 11,
    featured: 0,
  },
  {
    name: "Modern Apartment Interior",
    slug: "modern-apartment-interior",
    description:
      "A complete modern interior concept featuring minimalist decor and luxurious open space.",
    price: "1599.00",
    images: [
      "https://images.pexels.com/photos/6899359/pexels-photo-6899359.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ],
    categorySlug: "home-living",
    inventory: 3,
    rating: "4.9",
    reviewCount: 8,
    featured: 1,
  },
  // Sports
  {
    name: "Pro Padel Racket",
    slug: "pro-padel-racket",
    description:
      "Lightweight pro padel racket engineered for power, control, and competitive play.",
    price: "149.00",
    images: [
      "https://images.pexels.com/photos/11767210/pexels-photo-11767210.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "sports",
    inventory: 25,
    rating: "4.5",
    reviewCount: 33,
    featured: 0,
  },
  {
    name: "Performance Jersey",
    slug: "performance-jersey",
    description:
      "Breathable moisture-wicking jersey designed for training sessions and match day.",
    price: "89.00",
    images: [
      "https://images.pexels.com/photos/11767211/pexels-photo-11767211.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    ],
    categorySlug: "sports",
    inventory: 40,
    rating: "4.4",
    reviewCount: 27,
    featured: 1,
  },
];

let seeded = false;

export async function ensureSeed() {
  if (seeded) return;
  seeded = true;

  const existing = await db.select({ count: sql<number>`count(*)` }).from(categories);
  if (existing[0].count > 0) return;

  await db.insert(categories).values(categorySeed);

  const cats = await db.select().from(categories);
  const catMap = new Map(cats.map((c) => [c.slug, c.id]));

  const rows = productSeed.map((p) => ({
    ...p,
    categoryId: catMap.get(p.categorySlug) ?? null,
  }));

  await db.insert(products).values(rows);
}

export async function getCategories() {
  await ensureSeed();
  return db.select().from(categories).orderBy(categories.name);
}

export async function getProducts() {
  await ensureSeed();
  return db.query.products.findMany({
    with: { category: true },
    orderBy: (products, { desc }) => [desc(products.featured), desc(products.createdAt)],
  });
}

export async function getFeaturedProducts(limit = 8) {
  await ensureSeed();
  return db.query.products.findMany({
    with: { category: true },
    where: eq(products.featured, 1),
    orderBy: (products, { desc }) => desc(products.createdAt),
    limit,
  });
}

export async function getProductBySlug(slug: string) {
  await ensureSeed();
  return db.query.products.findFirst({
    where: eq(products.slug, slug),
    with: { category: true },
  });
}

export async function getCategoryBySlug(slug: string) {
  await ensureSeed();
  return db.query.categories.findFirst({
    where: eq(categories.slug, slug),
  });
}

export async function getProductsByCategory(slug: string) {
  await ensureSeed();
  const rows = await db
    .select()
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(categories.slug, slug))
    .orderBy(sql`${products.featured} desc, ${products.createdAt} desc`);
  return rows.map((r) => ({ ...r.products, category: r.categories }));
}

export async function getRelatedProducts(categoryId: number | null, excludeSlug: string, limit = 4) {
  await ensureSeed();
  if (!categoryId) {
    return db.query.products.findMany({
      with: { category: true },
      where: sql`${products.slug} != ${excludeSlug}`,
      limit,
      orderBy: (products, { desc }) => desc(products.featured),
    });
  }
  return db.query.products.findMany({
    with: { category: true },
    where: sql`${products.categoryId} = ${categoryId} and ${products.slug} != ${excludeSlug}`,
    limit,
    orderBy: (products, { desc }) => desc(products.featured),
  });
}

export interface OrderInput {
  email: string;
  name: string;
  address: string;
  city: string;
  country: string;
  postalCode: string;
  items: { productId: number; quantity: number; price: number }[];
  total: number;
}

export async function createOrder(input: OrderInput) {
  return db.transaction(async (tx) => {
    const [order] = await tx
      .insert(orders)
      .values({
        email: input.email,
        name: input.name,
        address: input.address,
        city: input.city,
        country: input.country,
        postalCode: input.postalCode,
        total: input.total.toFixed(2),
      })
      .returning({ id: orders.id });

    await tx.insert(orderItems).values(
      input.items.map((item) => ({
        orderId: order.id,
        productId: item.productId,
        quantity: item.quantity,
        price: item.price.toFixed(2),
      }))
    );

    return order;
  });
}
