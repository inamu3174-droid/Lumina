"use client";

import { SectionReveal, StaggerContainer, StaggerItem } from "@/components/animation/SectionReveal";
import { ProductCard } from "@/components/shop/ProductCard";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

type Product = {
  id: number;
  slug: string;
  name: string;
  price: string;
  compareAtPrice: string | null;
  images: string[];
  rating: string | null;
  reviewCount: number;
  category: { name: string; slug: string } | null;
};

interface FeaturedProductsProps {
  products: Product[];
}

export function FeaturedProducts({ products }: FeaturedProductsProps) {
  return (
    <section className="bg-surface py-24">
      <div className="mx-auto max-w-7xl px-6">
        <SectionReveal className="mb-12 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <span className="text-sm font-semibold uppercase tracking-widest text-primary">
              Curated Selection
            </span>
            <h2 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
              Featured Products
            </h2>
          </div>
          <Link
            href="/shop"
            className="group inline-flex items-center gap-2 text-sm font-medium text-slate-300 transition-colors hover:text-primary"
          >
            View All
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </SectionReveal>

        <StaggerContainer className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <StaggerItem key={product.id}>
              <ProductCard product={product} />
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}
