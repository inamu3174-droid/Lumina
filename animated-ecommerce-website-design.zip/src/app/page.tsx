import { getCategories, getFeaturedProducts } from "@/lib/data";
import { Hero } from "@/components/home/Hero";
import { Categories } from "@/components/home/Categories";
import { FeaturedProducts } from "@/components/home/FeaturedProducts";
import { USPStrip } from "@/components/home/USPStrip";
import { Newsletter } from "@/components/home/Newsletter";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [categories, featured] = await Promise.all([
    getCategories(),
    getFeaturedProducts(8),
  ]);

  return (
    <>
      <Hero />
      <USPStrip />
      <Categories categories={categories} />
      <FeaturedProducts products={featured} />
      <Newsletter />
    </>
  );
}
