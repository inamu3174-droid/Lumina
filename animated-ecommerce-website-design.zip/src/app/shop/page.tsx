import { ProductGrid } from "@/components/shop/ProductGrid";
import { getProducts } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function ShopPage() {
  const products = await getProducts();
  return <ProductGrid products={products} title="All Products" />;
}
