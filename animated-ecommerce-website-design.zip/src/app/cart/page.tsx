"use client";

import { Button } from "@/components/ui/Button";
import { useCart } from "@/components/providers/CartProvider";
import { formatPrice } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export default function CartPage() {
  const { items, updateQuantity, removeItem, totalPrice, totalItems } = useCart();

  if (items.length === 0) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6 pt-24 text-center">
        <div className="rounded-full bg-surface-elevated p-8">
          <ShoppingBag className="h-12 w-12 text-slate-500" />
        </div>
        <h1 className="mt-6 text-2xl font-bold">Your cart is empty</h1>
        <p className="mt-2 text-slate-400">Discover something extraordinary.</p>
        <Link
          href="/shop"
          className="mt-6 inline-flex h-11 items-center justify-center rounded-full bg-primary px-8 text-sm font-medium text-white transition-colors hover:bg-violet-500"
        >
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-28 pb-16">
      <div className="mx-auto max-w-7xl px-6">
        <h1 className="text-3xl font-bold tracking-tight md:text-4xl">
          Shopping Cart ({totalItems})
        </h1>

        <div className="mt-10 grid gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <AnimatePresence initial={false}>
              {items.map((item) => (
                <motion.div
                  key={item.productId}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="flex gap-5 border-b border-border py-6 first:pt-0"
                >
                  <div className="relative h-28 w-28 flex-shrink-0 overflow-hidden rounded-2xl bg-surface-elevated">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      className="object-cover"
                      sizes="112px"
                      unoptimized
                    />
                  </div>
                  <div className="flex flex-1 flex-col justify-between">
                    <div className="flex items-start justify-between gap-4">
                      <Link
                        href={`/product/${item.slug}`}
                        className="font-semibold text-slate-100 hover:text-primary"
                      >
                        {item.name}
                      </Link>
                      <span className="font-bold text-white">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 rounded-full border border-border bg-background px-2 py-1">
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                          className="rounded-full p-1.5 text-slate-400 hover:bg-white/5 hover:text-white"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="min-w-[1.5rem] text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                          className="rounded-full p-1.5 text-slate-400 hover:bg-white/5 hover:text-white"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                      <button
                        onClick={() => removeItem(item.productId)}
                        className="flex items-center gap-1 text-sm text-slate-500 transition-colors hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" /> Remove
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <div className="h-fit rounded-3xl bg-surface-elevated p-6 lg:sticky lg:top-28">
            <h2 className="text-lg font-semibold">Order Summary</h2>
            <div className="mt-6 space-y-3 text-sm">
              <div className="flex justify-between text-slate-400">
                <span>Subtotal</span>
                <span>{formatPrice(totalPrice)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between border-t border-border pt-3 text-base font-bold text-white">
                <span>Total</span>
                <span>{formatPrice(totalPrice)}</span>
              </div>
            </div>
            <Link
              href="/checkout"
              className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-full bg-primary text-sm font-medium text-white transition-colors hover:bg-violet-500"
            >
              Proceed to Checkout
            </Link>
            <Link
              href="/shop"
              className="mt-3 inline-flex h-12 w-full items-center justify-center rounded-full border border-border text-sm font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
            >
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
