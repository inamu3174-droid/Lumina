"use client";

import { Button } from "@/components/ui/Button";
import { useCart } from "@/components/providers/CartProvider";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";
import { ShoppingBag, Star } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

interface ProductCardProps {
  product: {
    id: number;
    slug: string;
    name: string;
    price: string;
    compareAtPrice: string | null;
    images: string[];
    rating: string | null;
    reviewCount: number;
    category: { name: string; slug: string } | null;
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const priceNum = parseFloat(product.price);
  const compareNum = product.compareAtPrice ? parseFloat(product.compareAtPrice) : null;
  const image = product.images[0] ?? "/images/placeholder.jpg";

  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="group flex flex-col overflow-hidden rounded-3xl bg-surface-elevated border border-border"
    >
      <Link href={`/product/${product.slug}`} className="relative aspect-[4/5] overflow-hidden">
        <Image
          src={image}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-110"
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          unoptimized
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
        {compareNum && (
          <span className="absolute left-3 top-3 rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-secondary-foreground">
            Sale
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-5">
        <div className="mb-2 flex items-center gap-1 text-xs text-slate-400">
          <Star className="h-3.5 w-3.5 fill-secondary text-secondary" />
          <span>{product.rating ?? "0.0"}</span>
          <span>({product.reviewCount})</span>
          <span className="mx-1">·</span>
          <Link
            href={`/shop/${product.category?.slug}`}
            className="hover:text-primary"
          >
            {product.category?.name ?? "General"}
          </Link>
        </div>
        <Link href={`/product/${product.slug}`} className="group/link">
          <h3 className="text-base font-semibold text-slate-100 transition-colors group-hover/link:text-primary">
            {product.name}
          </h3>
        </Link>
        <div className="mt-auto flex items-center justify-between pt-4">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-white">{formatPrice(priceNum)}</span>
            {compareNum && (
              <span className="text-sm text-slate-500 line-through">
                {formatPrice(compareNum)}
              </span>
            )}
          </div>
          <Button
            size="sm"
            onClick={() =>
              addItem({
                productId: product.id,
                slug: product.slug,
                name: product.name,
                price: priceNum,
                image,
              })
            }
            aria-label={`Add ${product.name} to cart`}
          >
            <ShoppingBag className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
