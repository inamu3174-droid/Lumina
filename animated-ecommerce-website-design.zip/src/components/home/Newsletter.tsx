"use client";

import { Button } from "@/components/ui/Button";
import { SectionReveal } from "@/components/animation/SectionReveal";
import { Send } from "lucide-react";
import { useState } from "react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  return (
    <section className="mx-auto max-w-7xl px-6 py-24">
      <SectionReveal className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-primary to-violet-800 px-6 py-16 text-center md:px-16 md:py-24">
        <div className="relative z-10 mx-auto max-w-2xl">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Join the Inner Circle
          </h2>
          <p className="mt-4 text-white/80">
            Be the first to know about new arrivals, exclusive offers, and
            curated style guides.
          </p>
          {submitted ? (
            <p className="mt-8 text-lg font-medium text-white">
              Thank you for subscribing!
            </p>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (email) setSubmitted(true);
              }}
              className="mt-8 flex flex-col gap-3 sm:flex-row"
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="h-14 flex-1 rounded-full border border-white/20 bg-white/10 px-6 text-white placeholder:text-white/50 focus:border-white focus:outline-none focus:ring-1 focus:ring-white"
              />
              <Button
                type="submit"
                variant="secondary"
                size="lg"
                className="min-w-[160px]"
              >
                Subscribe <Send className="h-4 w-4" />
              </Button>
            </form>
          )}
        </div>
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
      </SectionReveal>
    </section>
  );
}
