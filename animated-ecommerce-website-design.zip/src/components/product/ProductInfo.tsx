"use client";

import { Button } from "@/components/ui/Button";
import { useCart } from "@/components/providers/CartProvider";
import { formatPrice } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Minus, Plus, ShoppingBag, Star, Truck } from "lucide-react";
import { useState } from "react";

interface ProductInfoProps {
  product: {
    id: number;
    slug: string;
    name: string;
    description: string;
    price: string;
    compareAtPrice: string | null;
    rating: string | null;
    reviewCount: number;
    inventory: number;
    images: string[];
    category: { name: string; slug: string } | null;
  };
}

export function ProductInfo({ product }: ProductInfoProps) {
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const priceNum = parseFloat(product.price);
  const compareNum = product.compareAtPrice ? parseFloat(product.compareAtPrice) : null;

  const handleAdd = () => {
    addItem(
      {
        productId: product.id,
        slug: product.slug,
        name: product.name,
        price: priceNum,
        image: product.images[0] ?? "/images/placeholder.jpg",
      },
      quantity
    );
    setAdded(true);
    window.setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="flex flex-col">
      <div className="mb-2 flex items-center gap-2">
        <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
          {product.category?.name ?? "Lumina"}
        </span>
        <div className="flex items-center gap-1 text-sm text-slate-400">
          <Star className="h-4 w-4 fill-secondary text-secondary" />
          <span>{product.rating ?? "0.0"}</span>
          <span>({product.reviewCount} reviews)</span>
        </div>
      </div>

      <h1 className="text-3xl font-bold tracking-tight md:text-4xl lg:text-5xl">
        {product.name}
      </h1>

      <div className="mt-6 flex items-center gap-3">
        <span className="text-3xl font-bold text-white">{formatPrice(priceNum)}</span>
        {compareNum && (
          <span className="text-xl text-slate-500 line-through">
            {formatPrice(compareNum)}
          </span>
        )}
      </div>

      <p className="mt-6 leading-relaxed text-slate-300">{product.description}</p>

      <div className="mt-8 flex items-center gap-2 text-sm text-slate-400">
        <Truck className="h-4 w-4 text-primary" />
        Free shipping on orders over $100
      </div>

      <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="flex items-center gap-3 rounded-full border border-border bg-surface-elevated px-2 py-2">
          <button
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="rounded-full p-2 text-slate-400 hover:bg-white/5 hover:text-white"
          >
            <Minus className="h-4 w-4" />
          </button>
          <span className="min-w-[1.5rem] text-center font-medium">{quantity}</span>
          <button
            onClick={() => setQuantity((q) => Math.min(product.inventory, q + 1))}
            className="rounded-full p-2 text-slate-400 hover:bg-white/5 hover:text-white"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        <Button size="lg" className="flex-1" onClick={handleAdd} disabled={added}>
          <AnimatePresence mode="wait">
            {added ? (
              <motion.span
                key="added"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2"
              >
                <Check className="h-5 w-5" /> Added
              </motion.span>
            ) : (
              <motion.span
                key="add"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2"
              >
                <ShoppingBag className="h-5 w-5" /> Add to Cart
              </motion.span>
            )}
          </AnimatePresence>
        </Button>
      </div>
    </div>
  );
}
