"use client";

import { SectionReveal, StaggerContainer, StaggerItem } from "@/components/animation/SectionReveal";
import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";

interface Category {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  imageUrl: string | null;
}

interface CategoriesProps {
  categories: Category[];
}

export function Categories({ categories }: CategoriesProps) {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24">
      <SectionReveal className="mb-12 text-center">
        <span className="text-sm font-semibold uppercase tracking-widest text-primary">
          Browse by Category
        </span>
        <h2 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
          Find Your Style
        </h2>
      </SectionReveal>

      <StaggerContainer className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((category) => (
          <StaggerItem key={category.id}>
            <Link href={`/shop/${category.slug}`} className="group relative block overflow-hidden rounded-3xl">
              <div className="aspect-[4/3]">
                <Image
                  src={category.imageUrl ?? "/images/placeholder.jpg"}
                  alt={category.name}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  unoptimized
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="absolute bottom-0 left-0 p-6"
              >
                <h3 className="text-xl font-bold text-white">{category.name}</h3>
                <p className="mt-1 max-w-xs text-sm text-slate-300">
                  {category.description}
                </p>
              </motion.div>
            </Link>
          </StaggerItem>
        ))}
      </StaggerContainer>
    </section>
  );
}
