import { notFound } from "next/navigation";
import { ProductGrid } from "@/components/shop/ProductGrid";
import { getCategoryBySlug, getProductsByCategory } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ category: string }>;
}) {
  const { category } = await params;
  const [categoryData, products] = await Promise.all([
    getCategoryBySlug(category),
    getProductsByCategory(category),
  ]);

  if (!categoryData) {
    notFound();
  }

  return (
    <ProductGrid
      products={products}
      title={categoryData.name}
    />
  );
}
