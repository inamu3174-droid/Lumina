import { notFound } from "next/navigation";
import { ProductGallery } from "@/components/product/ProductGallery";
import { ProductInfo } from "@/components/product/ProductInfo";
import { ProductCard } from "@/components/shop/ProductCard";
import { SectionReveal, StaggerContainer, StaggerItem } from "@/components/animation/SectionReveal";
import { getProductBySlug, getRelatedProducts } from "@/lib/data";
import { ChevronRight } from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);

  if (!product) {
    notFound();
  }

  const related = await getRelatedProducts(product.categoryId, slug, 4);

  return (
    <div className="min-h-screen pt-24">
      <div className="mx-auto max-w-7xl px-6 py-8">
        <nav className="mb-8 flex items-center gap-2 text-sm text-slate-400">
          <Link href="/" className="hover:text-white">Home</Link>
          <ChevronRight className="h-4 w-4" />
          <Link href="/shop" className="hover:text-white">Shop</Link>
          {product.category && (
            <>
              <ChevronRight className="h-4 w-4" />
              <Link href={`/shop/${product.category.slug}`} className="hover:text-white">
                {product.category.name}
              </Link>
            </>
          )}
          <ChevronRight className="h-4 w-4" />
          <span className="text-white">{product.name}</span>
        </nav>

        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          <SectionReveal>
            <ProductGallery images={product.images} name={product.name} />
          </SectionReveal>
          <SectionReveal delay={0.15}>
            <ProductInfo product={product} />
          </SectionReveal>
        </div>

        {related.length > 0 && (
          <section className="mt-24">
            <SectionReveal className="mb-10">
              <h2 className="text-2xl font-bold tracking-tight md:text-3xl">
                You May Also Like
              </h2>
            </SectionReveal>
            <StaggerContainer className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((item) => (
                <StaggerItem key={item.id}>
                  <ProductCard product={item} />
                </StaggerItem>
              ))}
            </StaggerContainer>
          </section>
        )}
      </div>
    </div>
  );
}
