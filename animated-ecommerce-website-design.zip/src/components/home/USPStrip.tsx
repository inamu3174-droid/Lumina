"use client";

import { StaggerContainer, StaggerItem } from "@/components/animation/SectionReveal";
import { Headphones, ShieldCheck, Truck, Undo2 } from "lucide-react";

const usps = [
  { icon: Truck, title: "Free Shipping", desc: "On all orders over $100" },
  { icon: ShieldCheck, title: "Secure Payment", desc: "100% protected checkout" },
  { icon: Undo2, title: "Easy Returns", desc: "30-day hassle-free returns" },
  { icon: Headphones, title: "24/7 Support", desc: "Dedicated concierge team" },
];

export function USPStrip() {
  return (
    <section className="border-y border-border bg-surface-elevated">
      <div className="mx-auto max-w-7xl px-6 py-10">
        <StaggerContainer className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {usps.map((usp) => (
            <StaggerItem key={usp.title}>
              <div className="flex items-start gap-4">
                <div className="rounded-2xl bg-background p-3 text-primary">
                  <usp.icon className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-100">{usp.title}</h3>
                  <p className="mt-1 text-sm text-slate-400">{usp.desc}</p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerContainer>
      </div>
    </section>
  );
}
