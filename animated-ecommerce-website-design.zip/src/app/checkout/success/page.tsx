import { Button } from "@/components/ui/Button";
import { motion } from "framer-motion";
import { CheckCircle, Package } from "lucide-react";
import Link from "next/link";

export default async function SuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>;
}) {
  const { order } = await searchParams;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 pt-24 text-center">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", damping: 15 }}
        className="rounded-full bg-primary/10 p-8"
      >
        <CheckCircle className="h-16 w-16 text-primary" />
      </motion.div>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mt-8 text-3xl font-bold md:text-4xl"
      >
        Order Confirmed
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-3 max-w-md text-slate-400"
      >
        Thank you for shopping with Lumina. Your order
        {order ? ` #${order} ` : " "}
        has been received and is being prepared with care.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-8 flex flex-col gap-3 sm:flex-row"
      >
        <Link
          href="/shop"
          className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-primary px-8 text-sm font-medium text-white transition-colors hover:bg-violet-500"
        >
          <Package className="h-4 w-4" /> Continue Shopping
        </Link>
        <Link
          href="/"
          className="inline-flex h-12 items-center justify-center rounded-full border border-border px-8 text-sm font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
        >
          Back to Home
        </Link>
      </motion.div>
    </div>
  );
}
