"use client";

import { ProductCard } from "@/components/shop/ProductCard";
import { StaggerContainer, StaggerItem } from "@/components/animation/SectionReveal";
import { Search, SlidersHorizontal } from "lucide-react";
import { useMemo, useState } from "react";

type Product = {
  id: number;
  slug: string;
  name: string;
  price: string;
  compareAtPrice: string | null;
  images: string[];
  rating: string | null;
  reviewCount: number;
  category: { name: string; slug: string } | null;
};

interface ProductGridProps {
  products: Product[];
  title?: string;
}

export function ProductGrid({ products, title }: ProductGridProps) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"featured" | "price-asc" | "price-desc" | "rating">("featured");

  const filtered = useMemo(() => {
    let list = products.filter((p) =>
      p.name.toLowerCase().includes(query.toLowerCase())
    );
    list = [...list].sort((a, b) => {
      if (sort === "price-asc") return parseFloat(a.price) - parseFloat(b.price);
      if (sort === "price-desc") return parseFloat(b.price) - parseFloat(a.price);
      if (sort === "rating") return parseFloat(b.rating ?? "0") - parseFloat(a.rating ?? "0");
      return 0;
    });
    return list;
  }, [products, query, sort]);

  return (
    <section className="mx-auto max-w-7xl px-6 py-16">
      {title && (
        <h1 className="mb-8 text-center text-3xl font-bold tracking-tight md:text-4xl">
          {title}
        </h1>
      )}
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products..."
            className="h-11 w-full rounded-full border border-border bg-surface-elevated pl-10 pr-4 text-sm text-slate-100 placeholder:text-slate-500 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="h-4 w-4 text-slate-500" />
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as typeof sort)}
            className="h-11 rounded-full border border-border bg-surface-elevated px-4 text-sm text-slate-100 focus:border-primary focus:outline-none"
          >
            <option value="featured">Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="py-24 text-center text-slate-400">
          No products found matching your search.
        </div>
      ) : (
        <StaggerContainer className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {filtered.map((product) => (
            <StaggerItem key={product.id}>
              <ProductCard product={product} />
            </StaggerItem>
          ))}
        </StaggerContainer>
      )}
    </section>
  );
}
